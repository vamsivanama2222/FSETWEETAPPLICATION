package com.fse.usecase.control;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.fse.usecase.dao.TweetDao;
import com.fse.usecase.model.Users;
import com.fse.usecase.model.userTweets;
import com.fse.usecase.service.TweetService;

public class TweetApplication {
	public static Scanner sc=new Scanner(System.in);
	public static TweetLoginController tweetLoginController=new TweetLoginController();
	public static TweetOperationalController operationalController=new TweetOperationalController(); 
	public static void LoginModule()
	{
	
		System.out.println("***Welcome to TweetApplication***");
		System.out.println("Do you want to register or login?");
		System.out.println("1.Login");
		System.out.println("2.Register");
		
		int choice=sc.nextInt();
		switch (choice) {
		case 1:  
			    Users user=login_user();
			    if(user!=null)
			    	OperationalModule(user);
			    break;
		case 2:
			    boolean res_register=register_user();
			    if(res_register==true)
			    {
			    	
			    	System.out.println("Register Success please login...");
			    }
			    else
			    {
			    	System.out.println("Some Error while handling register...");
			    	register_user();
			    }
			    	

		default:
			break;
		}
		
	}
	private static boolean register_user() {
		boolean validated=false;
		
		String firstname,lastname,gender,dob,email,password;
		
		System.out.println("Please fill the required details for registration");
		//while(!validated) {
		System.out.println("Enter Firstname");
		 firstname =sc.next();
		//validated=register.nameValidator(firstname);
		 /*if(!validated) {System.out.println("Please Enter a Valid FirstName");
		registration.setFirstName(firstname);}
		}*/
		
		System.out.println("Enter Lastname");
		 lastname =sc.next();
	
		//if(!validated)break;
		System.out.println("Enter your gender");
		 gender =sc.next();
		System.out.println("Enter your Date-Of-Birth");
		 dob =sc.next();
		 Date userDob=null;
		 try {
		 userDob=new SimpleDateFormat("dd/MM/yyyy").parse(dob);  
		 }
		 catch (Exception e) {
			System.out.println("Date FOrmate Error!");
		}
		System.out.println("Enter your Email");
		 email =sc.next();
		System.out.println("Enter Password");
		 password =sc.next();
		 
		 Users newUser=new Users(firstname,lastname,gender,userDob,email,password);
		return  tweetLoginController.registerUser(newUser);
	}
	private static Users login_user() {
		System.out.println("Please Enter Login Id");
		String username =sc.next();
		System.out.println("Please Enter Pasword");
		String password =sc.next();
		Users user=tweetLoginController.isUserExist(username, password);
		if(user!=null) {
			System.out.println("Hello! "+user.getFirstName());
			
		}
		else
			System.out.println("Login Failed. Incorrect User name or Password");
		return user;
	}
	public static void OperationalModule(Users user)
	{
		System.out.println("Select a operation to proceed");
		System.out.println("1.Post a tweet");
		System.out.println("2.View All tweets");
		System.out.println("3.View My tweets");
		System.out.println("4.View all Users");
		System.out.println("5.Reset password/UpdatePassword");
		System.out.println("6.Logout");
		int ch=sc.nextInt();
		switch (ch) {
		case 1:
			System.out.println("Enter your Tweet Msg");
			Scanner sc1=new Scanner(System.in);
			String msg=sc1.nextLine();
			boolean res_Tweet=operationalController.postTweet(new userTweets(user.getFirstName(),user.getEmail(),msg));
			if(res_Tweet==true)
				System.out.println("Posted Tweet SuccessFully!...");
			else
				System.out.println("Sorry Something Went Wrong:)");
			OperationalModule(user);
			break;
		case 2:
			System.out.println("Here is All the userTweets");
			List<userTweets> allTweets=operationalController.getAllTweets();
			for (userTweets userTweets : allTweets) {
				System.out.println(userTweets.toString());
			}
			OperationalModule(user);
			break;
		case 3:
			System.out.println("Here is All My Tweets");
			List<userTweets> allMyTweets=operationalController.getAllMyTweets(user.getEmail());
			for (userTweets userTweets : allMyTweets) {
				System.out.println(userTweets.toString());
			}
			OperationalModule(user);
			break;
		case 4:
			System.out.println("Here is TweetApplicationUsers.....!");
			List<Users> allUsers=tweetLoginController.getAllUsers();
			for (Users user1 : allUsers) {
				System.out.println(user1.toString());
			}
			OperationalModule(user);
			break;
		case 5:
			System.out.println("Update Password is open for U ...!");
			String newPass=sc.next();
			boolean res=tweetLoginController.updateUserPassword(newPass, user.getEmail());
			if(res==true)
			{
				System.out.println("Hurrayy----!..password updates Successfullyy....:)");
				
			}
			else
			{
				System.out.println("Some thing went wrong please try again later...");
			}
			OperationalModule(user);
			break;
		case 6:
			System.out.println("Thank you for using Tweet Application...!");
			break;
		default:
			break;
		}
	}
	public static void main(String[] args) {
		
		
		while(true)
		{
			LoginModule();
		}
	
		
	}

}
