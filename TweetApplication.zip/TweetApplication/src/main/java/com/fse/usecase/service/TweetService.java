package com.fse.usecase.service;

import java.util.List;

import com.fse.usecase.dao.TweetDao;
import com.fse.usecase.model.Users;
import com.fse.usecase.model.userTweets;

public class TweetService {
	
	public List<Users> getAllUsers()
	{
		List<Users> allUsers=null;
		TweetDao tweetDao=new TweetDao();
	    allUsers=tweetDao.getData();
	    return allUsers;
	}
	public Users loginUser(String email,String password)
	{
		List<Users> allUsers=getAllUsers();
		for (Users users : allUsers) {
			if(users.getEmail().equals(email)&&users.getPassword().equals(password))
			{
				return users;
			}
		}
		return null;
	}
	public int registerUser(Users user)
	{
		TweetDao tweetDao=new TweetDao();
		return tweetDao.registerUser(user);
	}
	public List<userTweets> getAllTweets()
	{
		TweetDao tweetDao=new TweetDao();
		return tweetDao.getAllTweets();
	}
	public List<userTweets> getAllMyTweets(String email)
	{
		TweetDao tweetDao=new TweetDao();
		return tweetDao.getAllMyTweets(email);
	}
	public int registerTweet(userTweets tweet)
	{
		TweetDao tweetDao=new TweetDao();
		return tweetDao.registerTweet(tweet);
	}
	public int updatePassword(String newpassword,String email)
	{
		TweetDao tweetDao=new TweetDao();
		return tweetDao.updatePassword(newpassword, email);
	}

}
