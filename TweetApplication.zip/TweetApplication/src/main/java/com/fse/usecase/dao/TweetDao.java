package com.fse.usecase.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;
import com.fse.usecase.model.Users;
import com.fse.usecase.model.userTweets;

public class TweetDao {

	public TweetDao() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List<Users> getData() {
		List<Users> allusers = new ArrayList<Users>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/FSEUSECASECOM1", "root", "root");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from users");
			while (rs.next()) {

				Users user = new Users();
				user.setFirstName(rs.getString(1));
				user.setLastName(rs.getString(2));
				user.setGender(rs.getString(3));
				user.setDob(rs.getDate(4));
				user.setEmail(rs.getString(5));
				user.setPassword(rs.getString(6));
				allusers.add(user);

			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		return allusers;
	}

	public List<userTweets> getAllTweets() {
		List<userTweets> allTweets = new ArrayList<userTweets>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/FSEUSECASECOM1", "root", "root");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from usertweets");
			while (rs.next()) {

				userTweets userTweet = new userTweets();
				userTweet.setUserName(rs.getString(1));
				userTweet.setUserEmail(rs.getString(2));
				userTweet.setTweetMsg(rs.getString(3));

				allTweets.add(userTweet);

			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		return allTweets;
	}

	public int registerUser(Users user) {
		int result = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/FSEUSECASECOM1", "root", "root");
			PreparedStatement smt = con.prepareStatement("insert into users values(?,?,?,?,?,?)");
			smt.setString(1, user.getFirstName());
			smt.setString(2, user.getLastName());
			smt.setString(3, user.getGender());
			smt.setDate(4, null);
			smt.setString(5, user.getEmail());
			smt.setString(6, user.getPassword());
			result = smt.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		return result;
	}

	public int registerTweet(userTweets userT) {
		int result = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/FSEUSECASECOM1", "root", "root");
			PreparedStatement smt = con.prepareStatement("insert into usertweets values(?,?,?)");
			smt.setString(1, userT.getUserName());
			smt.setString(2, userT.getUserEmail());
			smt.setString(3, userT.getTweetMsg());

			result = smt.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		return result;
	}

	public List<userTweets> getAllMyTweets(String email) {
		List<userTweets> allTweets = new ArrayList<userTweets>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/FSEUSECASECOM1", "root", "root");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from usertweets where userEmail = '" + email + "'");
			while (rs.next()) {

				userTweets userTweet = new userTweets();
				userTweet.setUserName(rs.getString(1));
				userTweet.setUserEmail(rs.getString(2));
				userTweet.setTweetMsg(rs.getString(3));

				allTweets.add(userTweet);

			}
			con.close();

		} catch (Exception e) {

		}
		return allTweets;
	}

	public int updatePassword(String newPassword, String email) {
		int result = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/FSEUSECASECOM1", "root", "root");
			PreparedStatement smt = con.prepareStatement("update users set password=? where email=?");

			smt.setString(1, newPassword);
			smt.setString(2, email);

			result = smt.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		return result;
	}
}
