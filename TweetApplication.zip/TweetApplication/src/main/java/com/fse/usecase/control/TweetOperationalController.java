package com.fse.usecase.control;

import java.util.List;

import com.fse.usecase.model.userTweets;
import com.fse.usecase.service.TweetService;

public class TweetOperationalController {

	
	TweetService tweetService=new TweetService();
	
	public List<userTweets> getAllTweets()
	{
		return this.tweetService.getAllTweets();
	}
	public List<userTweets> getAllMyTweets(String email)
	{
		return this.tweetService.getAllMyTweets(email);
	}
	public boolean postTweet(userTweets tweet)
	{
		if(this.tweetService.registerTweet(tweet)==1)
		{
			return true;
		}
		return false;
			
	}
}
