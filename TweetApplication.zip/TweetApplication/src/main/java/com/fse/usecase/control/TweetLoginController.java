package com.fse.usecase.control;

import java.util.List;

import com.fse.usecase.model.Users;
import com.fse.usecase.service.TweetService;

public class TweetLoginController {

	TweetService tweetService=new TweetService();
	
	public Users isUserExist(String userName,String password)
	{
			Users user=this.tweetService.loginUser(userName, password);
			return user;
	}
	public boolean registerUser(Users newUser)
	{
		int res=this.tweetService.registerUser(newUser);
		if(res==1)
		{
			return true;
		}
		return false;
	}
	public boolean updateUserPassword(String newPassword,String user)
	{
		if(this.tweetService.updatePassword(newPassword, user)==1)
		{
			return true;
		}
		return false;
	}
	public List<Users> getAllUsers()
	{
		return this.tweetService.getAllUsers();
	}
}
